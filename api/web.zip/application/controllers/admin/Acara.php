<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Acara extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		belumlogin();
	}
	public function index()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['data'] = $this->db->query("SELECT * FROM acara ")->result_array();
		$this->load->view('admin/acara/data', $data);
	}

	public function add()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$query = $this->db->select('id_acara')->from('acara')->get()->last_row();
		if ($query) {
			$data['no'] = (int)$query->id_acara + 1;
		} else {
			$data['no'] = (int) 1;
		}
		$this->load->view('admin/acara/add', $data);
	}
	public function post()
	{
		$tanggal_selesai = $this->input->post('tanggal_selesai');
		$tanggal_mulai = $this->input->post('tanggal_mulai');
		$id_acara = $this->input->post('id_acara');
		$arr = [
			'id_acara' => $this->input->post('id_acara'),
			'nama_acara' => $this->input->post('nama_acara'),
			'tanggal_mulai' => $this->input->post('tanggal_mulai'),
			'tanggal_selesai' => $this->input->post('tanggal_selesai'),
			'jumlah_peserta' => $this->input->post('jumlah_peserta'),
			'jenis_kegiatan' => $this->input->post('jenis_kegiatan'),
			'deskripsi' => $this->input->post('desc'),
			'id_pengguna' => "",
			'status' => 2,
			'tipe_acara' => 2,
			'created_at' => date('Y-m-d H:i:s'),
		];
		$data = $this->db->query("SELECT * FROM acara  WHERE tanggal_mulai >= '$tanggal_mulai' AND tanggal_selesai <= '$tanggal_selesai' AND status != 3")->result_array();
		if ($data) {
			$this->session->set_flashdata('pesan', '<div class="alert alert-danger mb-3" role="alert">
			Acara Gagal, Karena tanggal telah di pesan
			</div>');
			redirect('admin/Acara');
		} else {

			$this->db->insert('acara', $arr);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
			Acara Berhasil Ditambahkan, Silahkan pilih fasilitas
			</div>');
			redirect('admin/Acara/fasilitas/' . $id_acara);
		}
	}

	public function detail($id)
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['data'] = $this->db->query("SELECT * FROM acara WHERE id_acara = '$id'")->row_array();
		$this->load->view('admin/acara/detailacara', $data);
	}
	public function fasilitas($id)
	{
		$this->form_validation->set_rules('id_fasilitas', 'id_fasilitas', 'required');
		if ($this->form_validation->run() == false) {
			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$data['data'] = $this->db->query("SELECT * FROM acara WHERE id_acara = '$id'")->result_array();
			// $data['fasilitas'] = $this->db->query("SELECT * FROM fasilitas")->result_array();
			$qry = $this->db->query("SELECT * FROM detail_acara , fasilitas WHERE detail_acara.id_fasilitas = fasilitas.id_fasilitas")->result_array();
			for ($i = 0; $i < count($qry); $i++) {
				$angka = $qry[$i]['id_fasilitas'];
				$dats[] = $angka;
			}
			if ($qry) {
				$bismillah = implode(', ', $dats);
				$data['fasilitas'] = $this->db->query("SELECT * FROM fasilitas WHERE id_fasilitas not in ($bismillah)")->result_array();
			} else {
				$data['fasilitas'] = $this->db->query("SELECT * FROM fasilitas")->result_array();
			}
			$data['detail'] = $this->db->query("SELECT * FROM detail_acara , fasilitas WHERE detail_acara.id_fasilitas = fasilitas.id_fasilitas AND id_acara = '$id'")->result_array();
			$this->load->view('admin/acara/tambah_fasilitas', $data);
		} else {
			$id_acara = $this->input->post('id_acara');
			$arr = [
				'id_acara' => $id_acara,
				'id_fasilitas' => $this->input->post('id_fasilitas'),
			];
			$this->db->insert('detail_acara', $arr);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
	Fasilitas Berhasil Ditambahkan
		</div>');
			redirect('admin/Acara/fasilitas/' . $id_acara);
		}
	}
	public function hapus($id)
	{
		$this->db->where('id_acara', $id);
		$this->db->delete('acara');
		$this->db->where('id_acara', $id);
		$this->db->delete('detail_acara');
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Data Berhasil Dihapus!
		</div>');
		redirect('admin/Acara');
	}
	public function hapusfasilitas($id)
	{
		$this->db->where('id_detail', $id);
		$this->db->delete('detail_acara');
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Data Berhasil Dihapus!
		</div>');
		redirect('admin/Acara');
	}
	public function Selesai($id)
	{
		// echo "terima";
		$query = $this->db->query("SELECT acara.* , pengguna.id_pengguna , pengguna.token FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna")->row_array();
		$token = $query['token'];
		$id_pengguna = $query['id_pengguna'];
		// echo $token;
		$this->db->set('status', 4);
		$this->db->where('id_acara', $id);
		$this->db->update('acara');
		$this->sendNotification($token, "Acara Anda Telah Selesai", "Desa Ngoran", 2, $id);
		$arr = [
			'keterangan' => "Acara Anda Telah Selesai",
			'id_acara' => $id,
			'id_pengguna' => $id_pengguna,
			'created_at' => date("Y-m-d H:i:s")
		];
		$this->db->insert('pemberitahuan', $arr);
		//create ntif
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Acara Telah Selesai
		</div>');
		redirect('admin/Acara');
	}
	public function Terima($id)
	{
		// echo "terima";
		$query = $this->db->query("SELECT acara.* , pengguna.id_pengguna , pengguna.token FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna")->row_array();
		$token = $query['token'];
		$id_pengguna = $query['id_pengguna'];
		// echo $token;
		$this->db->set('status', 2);
		$this->db->where('id_acara', $id);
		$this->db->update('acara');
		$this->sendNotification($token, "Acara Anda Telah Diterima Oleh Admin", "Desa Ngoran", 2, $id);

		$arr = [
			'keterangan' => "Acara Anda Telah Diterima",
			'id_acara' => $id,
			'id_pengguna' => $id_pengguna,
			'created_at' => date("Y-m-d H:i:s")
		];
		$this->db->insert('pemberitahuan', $arr);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Acara Diterima
		</div>');
		redirect('admin/Acara');
	}
	public function Tolak($id)
	{
		// echo "tolak";
		$query = $this->db->query("SELECT acara.* , pengguna.id_pengguna , pengguna.token FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna")->row_array();
		$token = $query['token'];
		$id_pengguna = $query['id_pengguna'];
		$this->db->set('status', 3);
		$this->db->where('id_acara', $id);
		$this->db->update('acara');
		$this->sendNotification($token, "Acara Anda Telah Ditolak Oleh Admin", "Desa Ngoran", 3, $id);
		$arr = [
			'keterangan' => "Acara Anda Telah Ditolak",
			'id_acara' => $id,
			'id_pengguna' => $id_pengguna,
			'created_at' => date("Y-m-d H:i:s")
		];
		$this->db->insert('pemberitahuan', $arr);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Acara Ditolak
		</div>');
		redirect('admin/Acara');
	}
	public function sendNotification($id, $pesan, $title, $key, $ids)
	{
		$registrationIds = array($id);
		$msg = array(
			'key'   => $key,
			'id_acara'   => $ids,
			'message'   => $pesan,
			'title'     => $title,
			'subtitle'  => 'This is a subtitle. subtitle',
			'tickerText'    => 'Ticker text here...Ticker text here...Ticker text here',
			'vibrate'   => 1,
			'sound'     => 1,
			'largeIcon' => 'large_icon',
			'smallIcon' => 'small_icon'
		);
		$fields = array(
			'registration_ids'  => $registrationIds,
			'data'          => $msg
		);

		$headers = array(
			'Authorization: key= AAAAeaoPUqk:APA91bE8haPM5Jb21WjTBQx3RBLYWKLBnK6LyT0_BqVoRfo3Iy7YCkrGNZWXFKTQV_LLzTM3DYTVrdBTqEZoa8jhLOB1CDIiu5Z_ECBfz-isSTiruKT_bSpj7L6-UeJEZHGcYgbWGmE5',
			'Content-Type: application/json'
		);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
		$result = curl_exec($ch);
		curl_close($ch);
		// echo $result;
	}
	public function surat($id)
	{
		$data['surat'] = $this->db->query("SELECT * FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna AND acara.id_acara = '$id'")->row_array();
		$this->load->view('admin/surat/terima', $data);
	}
}
