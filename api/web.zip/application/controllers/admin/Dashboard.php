<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		belumlogin();
	}
	public function index()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['user'] = $this->db->query("SELECT * FROM pengguna WHERE status = 2")->num_rows();
		$data['fasilitas'] = $this->db->query("SELECT * FROM fasilitas")->num_rows();
		$data['pemesan'] = $this->db->query("SELECT * FROM acara")->num_rows();
		$data['menunggu'] = $this->db->query("SELECT * FROM acara WHERE status = 1")->num_rows();
		$data['lampu'] = $this->db->query("SELECT * FROM lampu")->result_array();
		$data['testi'] = $this->db->query("SELECT testimoni.* , pengguna.nama FROM testimoni , pengguna WHERE pengguna.id_pengguna = testimoni.id_pengguna ORDER BY tanggal DESC")->result_array();

		$acara =  $this->db->query("SELECT COUNT(id_acara) as count,MONTHNAME(created_at) as month_name FROM acara WHERE YEAR(created_at) = '" . date('Y') . "' AND status != 3 GROUP BY YEAR(created_at), MONTH(created_at)")->result_array();

		foreach ($acara as $p) {
			$data['tanggal'][] = $p['month_name'];
			$data['jumlah'][] = (int)$p['count'];
		}
		$data['grafik'] = json_encode($data);
		$this->load->view('admin/dashboard', $data);
	}
}
