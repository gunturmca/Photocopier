<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Fasilitas extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('User_Model', 'Models');
		belumlogin();
	}
	public function index()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['fasilitas'] = $this->db->query("SELECT * FROM fasilitas")->result_array();
		$this->load->view('admin/fasilitas/data', $data);
	}

	public function add()
	{
		$this->form_validation->set_rules('fasilitas', 'fasilitas', 'required');
		if ($this->form_validation->run() == false) {
			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$data['kd'] = $this->Models->randomkode(32);
			$this->load->view('admin/fasilitas/add', $data);
		} else {
			$key = $this->Models->randomkode(4);
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['max_size'] = '2048';
			$config['upload_path'] = './uploads/Fasilitas/';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			if ($this->upload->do_upload('gambar')) {
				$fotobaru = $this->upload->data('file_name');
				$insert = array(
					'nama_fasilitas' => $this->input->post('fasilitas'),
					'gambar_fasilitas' => 	$fotobaru,
					'keterangan' => $this->input->post('keterangan'),
				);
				if ($this->Models->insert('fasilitas', $insert)) {
					$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
					  Data Fasilitas Berhasil Ditambahkan
					</div>');
					redirect('admin/Fasilitas');
				} else {
					$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Terjadi Kesalahan</div>');
					redirect('admin/Fasilitas');
				}
			} else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">'
					. $this->upload->display_errors() .
					'</div>');
				redirect('admin/Fasilitas');
			}
		}
	}
	public function edit($id)
	{
		$this->form_validation->set_rules('fasilitas', 'fasilitas', 'required');
		if ($this->form_validation->run() == false) {

			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$data['fasilitas'] = $this->db->query("SELECT * FROM fasilitas WHERE id_fasilitas = '$id'")->result_array();
			$this->load->view('admin/fasilitas/edit',	$data);
		} else {
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['max_size'] = '2048';
			$config['upload_path'] = './uploads/Fasilitas/';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			if ($this->upload->do_upload('gambar')) {
				$fotobaru = $this->upload->data('file_name');
				$insert = array(
					'nama_fasilitas' => $this->input->post('fasilitas'),
					'gambar_fasilitas' => $fotobaru,
					'keterangan' => $this->input->post('keterangan'),
				);
				$this->db->where('id_fasilitas', $id);
				$this->db->update('fasilitas', $insert);
				$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
				Data Fasilitas Berhasil Diubah
			</div>');
				redirect('admin/Fasilitas');
			} else {
				$insert = array(
					'nama_fasilitas' => $this->input->post('fasilitas'),
					'keterangan' => $this->input->post('keterangan'),
				);
				$this->db->where('id_fasilitas', $id);
				$this->db->update('fasilitas', $insert);
				$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
				Data Fasilitas Berhasil Diubah
			</div>');
				redirect('admin/Fasilitas');
			}
		}
	}
	public function off($id)
	{
		// $post = $this->input->post();
		$this->db->set('active', 0);
		$this->db->where('id', $id);
		$qry = $this->db->update('fasilitas');
		if ($qry) {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Data Berhasil Diubah
            </div>');
			redirect('admin/Fasilitas');
		} else {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Gagal Ubah Status
            </div>');
			redirect('admin/Fasilitas');
		}
	}
	public function on($id)
	{
		// $post = $this->input->post();
		$this->db->set('active', 1);
		$this->db->where('id', $id);
		$qry = $this->db->update('fasilitas');
		if ($qry) {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Data Berhasil Diubah
            </div>');
			redirect('admin/Fasilitas');
		} else {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Gagal Ubah Status
            </div>');
			redirect('admin/Fasilitas');
		}
	}
	public function hapus($id)
	{
		$this->db->where('id_fasilitas', $id);
		$this->db->delete('fasilitas');
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Data Berhasil Dihapus!
		</div>');
		redirect('admin/Fasilitas');
	}
}
