<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Lampu extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('User_Model', 'Maksi');
		belumlogin();
	}
	public function index()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['lampu'] = $this->db->query("SELECT * FROM lampu")->result_array();
		$this->load->view('admin/lampu/data', $data);
	}

	public function add()
	{
		$this->form_validation->set_rules('lampu', 'lampu', 'required');
		if ($this->form_validation->run() == false) {
			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$this->load->view('admin/lampu/add', $data);
		} else {
			$arr = [
				'nama_lampu' => $this->input->post('lampu'),
				'keterangan' => $this->input->post('keterangan'),
				'tindakan' => '2',
				'apiKey' => $this->input->post('apiKey'),
			];
			if ($this->Maksi->insert('lampu', $arr)) {
				$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3 mt-3" role="alert">
						Berhasil Menambahkan Lampu!
				</div>');
				redirect('admin/Lampu');
			} else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger mb-3" role="alert">
						Gagal Menambahkan Lampu!
				</div>');
				redirect('admin/Lampu');
			}
		}
	}

	public function edit($id)
	{
		$this->form_validation->set_rules('lampu', 'lampu', 'required');
		if ($this->form_validation->run() == false) {
			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$data['lampu'] = $this->db->query("SELECT * FROM lampu WHERE id_lampu = '$id'")->result_array();
			$this->load->view('admin/lampu/edit', $data);
		} else {
			$arr = [
				'nama_lampu' => $this->input->post('lampu'),
				'keterangan' => $this->input->post('keterangan'),
				'apiKey' => $this->input->post('apiKey'),
			];
			$this->db->where('id_lampu', $id);
			$this->db->update('lampu', $arr);
			$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
			Data Berhasil Di Update!
			</div>');
			redirect('admin/Lampu');
		}
	}
	public function off($id)
	{
		// $post = $this->input->post();
		$this->db->set('tindakan', 2);
		$this->db->where('id_lampu', $id);
		$qry = $this->db->update('lampu');
		if ($qry) {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Data Berhasil Diubah
            </div>');
			redirect('admin/Dashboard');
		} else {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Gagal Ubah Status
            </div>');
			redirect('admin/Dashboard');
		}
	}
	public function on($id)
	{
		// $post = $this->input->post();
		$this->db->set('tindakan', 1);
		$this->db->where('id_lampu', $id);
		$qry = $this->db->update('lampu');
		if ($qry) {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Data Berhasil Diubah
            </div>');
			redirect('admin/Dashboard');
		} else {
			$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
            Gagal Ubah Status
            </div>');
			redirect('admin/Dashboard');
		}
	}
	public function hapus($id)
	{
		$this->db->where('id_lampu', $id);
		$this->db->delete('lampu');
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Data Berhasil Dihapus!
		</div>');
		redirect('admin/Lampu');
	}
}
