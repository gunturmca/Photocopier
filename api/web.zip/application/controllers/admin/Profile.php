<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		belumlogin();
	}
	public function index()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['profile'] = $this->db->query("SELECT * FROM profile_gedung WHERE id = '1'")->row();
		$this->load->view('admin/profile/about', $data);
	}
	public function update()
	{
		$id = $this->input->post('id');
		$arr = [
			'nama' => $this->input->post('nama'),
			'deskripsi' => $this->input->post('deskripsi'),
		];
		$this->db->where('id', $id);
		$this->db->update('profile_gedung', $arr);
		$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
		Data Berhasil Diubah
		</div>');
		redirect('admin/Profile');
	}
}
