<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Surat extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function surat($id)
    {
        $data['surat'] = $this->db->query("SELECT * FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna AND acara.id_acara = '$id'")->row_array();
        $this->load->view('admin/surat/terima', $data);
    }
}
