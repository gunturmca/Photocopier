<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Testimoni extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    belumlogin();
  }
  public function index()
  {
    $data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
    $this->session->userdata('id_pengguna')])->row_array();
    $data['testi'] = $this->db->query("SELECT testimoni.* , pengguna.nama FROM testimoni , pengguna WHERE pengguna.id_pengguna = testimoni.id_pengguna ORDER BY tanggal DESC")->result_array();
    $this->load->view('admin/testimoni/testimoni', $data);
  }
  public function delete($id)
  {
    $this->db->where('id_testimoni', $id);
    $q = $this->db->delete('testimoni');
    if ($q) {
      $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
      Data Berhasil Dihapus
      </div>');
      redirect('admin/Testimoni');
    } else {
      $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
      Data Gagal Dihapus
      </div>');
      redirect('admin/Testimoni');
    }
  }
}
