<?php
defined('BASEPATH') or exit('No direct script access allowed');

class UnitDesa extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('User_Model', 'Models');
		belumlogin();
	}
	public function index()
	{
		$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
		$this->session->userdata('id_pengguna')])->row_array();
		$data['data'] = $this->db->query("SELECT * FROM unit_desa")->result_array();
		$this->load->view('admin/unitdesa/data', $data);
	}

	public function add()
	{
		$this->form_validation->set_rules('nama', 'nama', 'required');
		if ($this->form_validation->run() == false) {
			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$this->load->view('admin/unitdesa/add', $data);
		} else {
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['max_size'] = '2048';
			$config['upload_path'] = './uploads/unitdesa/';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			if ($this->upload->do_upload('gambar')) {
				$fotobaru = $this->upload->data('file_name');
				$insert = array(
					'nama_unit' => $this->input->post('nama'),
					'tgl_bentuk' => $this->input->post('tanggal'),
					'gambar' => 	$fotobaru,
					'deskripsi' => $this->input->post('desc'),
					'created_at' => date("Y-m-d H:i:s"),
				);
				if ($this->Models->insert('unit_desa', $insert)) {
					$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
					  Data UnitDesa Berhasil Ditambahkan
					</div>');
					redirect('admin/UnitDesa');
				} else {
					$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">Terjadi Kesalahan</div>');
					redirect('admin/UnitDesa');
				}
			} else {
				$this->session->set_flashdata('pesan', '<div class="alert alert-danger" role="alert">'
					. $this->upload->display_errors() .
					'</div>');
				redirect('admin/UnitDesa');
			}
		}
	}
	public function edit($id)
	{
		$this->form_validation->set_rules('nama', 'nama', 'required');
		if ($this->form_validation->run() == false) {
			$data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
			$this->session->userdata('id_pengguna')])->row_array();
			$data['data'] = $this->db->query("SELECT * FROM unit_desa WHERE id_unit = '$id'")->row_array();
			$this->load->view('admin/unitdesa/edit', $data);
		} else {
			$config['allowed_types'] = 'jpg|jpeg|png|gif';
			$config['max_size'] = '2048';
			$config['upload_path'] = './uploads/unitdesa/';
			$config['encrypt_name'] = TRUE;
			$this->load->library('upload', $config);
			if ($this->upload->do_upload('gambar')) {
				$fotobaru = $this->upload->data('file_name');
				$insert = array(
					'nama_unit' => $this->input->post('nama'),
					'gambar' => $fotobaru,
					'tgl_bentuk' => $this->input->post('tanggal'),
					'deskripsi' => $this->input->post('desc'),
				);
				$this->db->where('id_unit', $id);
				$this->db->update('unit_desa', $insert);
				$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
				Data Unit Desa Berhasil Diubah
			</div>');
				redirect('admin/UnitDesa');
			} else {
				$insert = array(
					'nama_unit' => $this->input->post('nama'),
					'tgl_bentuk' => $this->input->post('tanggal'),
					'deskripsi' => $this->input->post('desc'),
				);
				$this->db->where('id_unit', $id);
				$this->db->update('unit_desa', $insert);
				$this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
				Data Unit Desa Berhasil Diubah
			</div>');
				redirect('admin/UnitDesa');
			}
		}
	}
	public function delete($id)
	{
		$this->db->where('id_unit', $id);
		$this->db->delete('unit_desa');
		$this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
		Data Berhasil Dihapus!
		</div>');
		redirect('admin/UnitDesa');
	}
}
