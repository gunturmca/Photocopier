<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    belumlogin();
  }
  public function index()
  {
    $data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
    $this->session->userdata('id_pengguna')])->row_array();
    $data['user'] = $this->db->query("SELECT * FROM pengguna WHERE status = 2")->result_array();
    $this->load->view('admin/user/data', $data);
  }
  public function edit()
  {
    $data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
    $this->session->userdata('id_pengguna')])->row_array();
    $data['user'] = $this->db->query("SELECT * FROM pengguna WHERE status = 1")->row_array();
    $this->load->view('admin/user/edit', $data);
  }

  public function post_edit()
  {
    $arr = [
      'nama' => $this->input->post('nama'),
      'email' => $this->input->post('email'),
      'password' => md5($this->input->post('password')),
    ];

    $this->db->where('status', 1);
    $this->db->update('pengguna', $arr);
    $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">
    Data Admin Berhasil Diubah
  </div>');
    redirect('admin/Dashboard');
  }


  public function detail($id)
  {
    $data['Pengguna'] = $this->db->get_where('pengguna', ['id_pengguna' =>
    $this->session->userdata('id_pengguna')])->row_array();
    $data['data'] = $this->db->query("SELECT * FROM pengguna WHERE id_pengguna = '$id'")->row_array();
    $this->load->view('admin/user/detail', $data);
  }

  public function Off($id)
  {
    $this->db->set('is_active', 2);
    $this->db->where('id_pengguna', $id);
    $this->db->update('pengguna');

    $this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
	Akun Telah Di Unblock
		</div>');
    redirect('admin/User');
  }

  public function On($id)
  {
    $this->db->set('is_active', 1);
    $this->db->where('id_pengguna', $id);
    $this->db->update('pengguna');

    $this->session->set_flashdata('pesan', '<div class="alert alert-success mb-3" role="alert">
	Akun Telah Aktif
		</div>');
    redirect('admin/User');
  }
}
