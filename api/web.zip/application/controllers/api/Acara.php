<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Acara extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'user');
  }
  public function index_post()
  {
    $date = date('Y-m-d H:i:s');
    $idp =  $this->input->post('id_pengguna');
    $tanggal_selesai = $this->input->post('tanggal_selesai');
    $tanggal_mulai = $this->input->post('tanggal_mulai');
    $arr = [
      'nama_acara' => $this->input->post('nama_acara'),
      'tanggal_mulai' => $this->input->post('tanggal_mulai'),
      'tanggal_selesai' => $this->input->post('tanggal_selesai'),
      'jumlah_peserta' => $this->input->post('jumlah_peserta'),
      'jenis_kegiatan' => $this->input->post('jenis_kegiatan'),
      'deskripsi' => $this->input->post('deskripsi'),
      'id_pengguna' => $idp,
      'status' => 1,
      'tipe_acara' => 1,
      'created_at' => $date,
    ];
    $data = $this->db->query("SELECT acara.* , pengguna.nama as nama_user FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna AND tanggal_mulai >= '$tanggal_mulai' AND tanggal_selesai <= '$tanggal_selesai' AND status != 3")->result_array();
    if ($data) {
      $response = [
        'status' => false,
        'pesan' => 'Maaf gedung telah terbooking di tanggal yang sama',
      ];
      $this->response($response, 400);
    } else {
      if ($this->user->insert('acara', $arr)) {
        $dataku = $this->db->query("SELECT * FROM acara WHERE created_at = '$date' AND id_pengguna = '$idp'")->row_array();
        $response = [
          'status' => true,
          'data' => $dataku,
          'pesan' => 'Acara Berhasil Ditambahkan, Selanjutnya tambah fasilitas yang ingin anda gunakan',
        ];
        $this->response($response, 200);
      } else {
        $response = [
          'status' => false,
          'pesan' => 'Acara Gagal Ditambahkan',
        ];
        $this->response($response, 400);
      }
    }
  }
  public function index_get()
  {
    $data = $this->db->query("SELECT acara.* , pengguna.nama as nama_user FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna")->result_array();
    if ($data) {
      $response = [
        'status' => true,
        'data' => $data,
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => true,
        'pesan' => 'Acara Tidak Tersedia',
      ];
      $this->response($response, 400);
    }
  }
}
