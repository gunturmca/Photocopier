<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class AcaraById extends REST_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'user');
  }
  public function index_post()
  {
    $id = $this->input->post('id_pengguna');
    $data = $this->db->query("SELECT acara.* , pengguna.nama as nama_user FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna AND acara.id_pengguna = '$id'")->result_array();
    if ($data) {
      $response = [
        'status' => true,
        'data' => $data,
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => true,
        'pesan' => 'Acara Tidak Tersedia',
      ];
      $this->response($response, 400);
    }
  }
}
