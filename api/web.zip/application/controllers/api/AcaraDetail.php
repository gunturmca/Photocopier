<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class AcaraDetail extends REST_Controller
{

  public function index_get()
  {
    $id = $this->get('id_acara');
    $data = $this->db->query("SELECT acara.* , pengguna.nama as nama_user FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna AND id_acara = '$id'")->row_array();
    if ($data) {
      $response = [
        'status' => true,
        'data' => $data,
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => true,
        'pesan' => 'Acara Tidak Tersedia',
      ];
      $this->response($response, 400);
    }
  }
}
