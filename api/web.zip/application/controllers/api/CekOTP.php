<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class CekOTP extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    // Load User Model
    // $this->load->model('api/User_Model', 'UserModel');
  }
  public function index_post()
  {
    $kode_otp = $this->input->post('kode_otp');
    $email = $this->input->post('email');
    $query = $this->db->query("SELECT * FROM pengguna WHERE email = '$email'")->row_array();
    if ($query['kode_otp'] == $kode_otp) {
      $this->db->set('is_active', 1);
      $this->db->where('email', $query['email']);
      $this->db->update('pengguna');
      $message = array(
        'status' => true,
        'data' => "Akun Anda Telah Aktif"
      );
      $this->response($message, REST_Controller::HTTP_OK);
    } else {
      $message = array(
        'status' => false,
        'data' => "Kode OTP Salah"
      );
      $this->response($message, REST_Controller::HTTP_OK);
    }
  }
}
