<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Fasilitas extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'user');
  }
  public function index_get()
  {
    $id_acara = $this->get('id_acara');
    $qry = $this->db->query("SELECT * FROM fasilitas , detail_acara WHERE detail_acara.id_fasilitas = fasilitas.id_fasilitas AND detail_acara.id_acara = '$id_acara'")->result_array();
    for ($i = 0; $i < count($qry); $i++) {
      $angka = $qry[$i]['id_fasilitas'];
      $dats[] = $angka;
    }
    echo json_encode($qry);
    if ($qry) {
      $bismillah = implode(', ', $dats);
      $data = $this->db->query("SELECT * FROM fasilitas WHERE id_fasilitas not in ($bismillah)")->result_array();
    } else {
      $data = $this->db->query("SELECT * FROM fasilitas")->result_array();
    }
    // $data = $this->db->query("SELECT * FROM fasilitas")->result_array();
    if ($data) {
      $response = [
        'status' => true,
        'data' => $data,
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => false,
        'pesan' => 'Fasilitas Tidak Tersedia',
      ];
      $this->response($response, 400);
    }
  }

  public function index_post()
  {
    $arr = [
      'id_acara' => $this->input->post('id_acara'),
      'id_fasilitas' => $this->input->post('id_fasilitas'),
    ];
    if ($this->user->insert('detail_acara', $arr)) {
      $response = [
        'status' => true,
        'pesan' => 'Acara Berhasil Ditambahkan, tunggu konfirmasi dari admin',
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => false,
        'pesan' => 'Acara Gagal Ditambahkan',
      ];
      $this->response($response, 400);
    }
  }
}
