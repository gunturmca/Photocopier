<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class FasilitasById extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'user');
  }
  public function index_get()
  {
    $ids = $this->get('id_acara');
    $data = $this->db->query("SELECT detail_acara.*  , fasilitas.nama_fasilitas FROM detail_acara , fasilitas WHERE detail_acara.id_fasilitas = fasilitas.id_fasilitas AND id_acara = '$ids'")->result_array();
    if ($data) {
      $response = [
        'status' => true,
        'data' => $data,
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => false,
        'pesan' => 'Fasilitas Tidak Tersedia',
      ];
      $this->response($response, 400);
    }
  }
}
