<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Logout extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
  }
  public function index_post()
  {
    $id_pengguna = $this->input->post('id_pengguna');
    $pengguna = $this->db->query("SELECT * FROM pengguna WHERE id_pengguna = '$id_pengguna'")->result_array();
    if ($pengguna) {
      $this->db->set('token', "");
      $this->db->where('id_pengguna', $id_pengguna);
      $this->db->update('pengguna');
      $this->response([
        'status' => TRUE,
        'message' => "Berhasil Logout"
      ], REST_Controller::HTTP_OK);
    } else {
      $this->response([
        'status' => FALSE,
        'message' => 'Gagal Logout'
      ], REST_Controller::HTTP_NOT_FOUND);
    }
  }
}
