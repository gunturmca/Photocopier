<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Profile extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_Model', 'user');
    }
    public function index_get()
    {
        $data = $this->db->query("SELECT * FROM profile_gedung WHERE id = '1'")->row();
        if ($data) {
            $response = [
                'status' => true,
                'data' => $data,
            ];
            $this->response($response, 200);
        } else {
            $response = [
                'status' => false,
                'pesan' => 'Profile Tidak Tersedia',
            ];
            $this->response($response, 400);
        }
    }
}
