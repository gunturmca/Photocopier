<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Register extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'UserModel');
  }
  public function index_post()
  {
    $email = $this->input->post('email');
    $password = md5($this->input->post('password'));
    $nomor_telepon = $this->input->post('nomor_telepon');
    $nama = $this->input->post('nama');
    $cek = $this->db->get_where('pengguna', ['email' => $email])->row_array();
    $cektelp = $this->db->get_where('pengguna', ['nomor_telepon' => $nomor_telepon])->row_array();

    $keyOtp = $this->UserModel->randomNomor(4);
    if ($cek > 0) {
      $response = [
        'status' => false,
        'message' => "Maaf Email Telah Digunakan",
      ];
      $this->response($response, 404);
    } else if ($cektelp > 0) {
      $response = [
        'status' => false,
        'message' => "Maaf Nomor Telepon Telah Terdaftar",
      ];
      $this->response($response, 404);
    } else {
      $arr = [
        'nama' => $nama,
        'email' => $email,
        'alamat' => $this->input->post('alamat'),
        'nomor_telepon' => $this->input->post('nomor_telepon'),
        'kota_kab' => $this->input->post('kota_kab'),
        'provinsi' => $this->input->post('provinsi'),
        'jenis_kelamin' => $this->input->post('jenis_kelamin'),
        'password' => $password,
        'foto_pengguna' => "",
        'token' => "",
        'kode_otp' => $keyOtp,
        'status' => 2,
        'is_active' => 2,
        'created_at' => date('Y-m-d H:i:s'),
      ];
      if ($this->UserModel->insert('pengguna', $arr)) {
        $response = [
          'status' => true,
          'pesan' => 'Pendaftaran Akun Berhasil',
        ];
        $this->response($response, 200);
      } else {
        $response = [
          'status' => true,
          'pesan' => 'Pendaftaran Akun Gagal',
        ];
        $this->response($response, 404);
      }
    }
  }
}
