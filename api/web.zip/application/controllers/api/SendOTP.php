<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class SendOTP extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'user');
  }
  public function index_post()
  {
    $email = $this->input->post('email');
    $query = $this->db->query("SELECT * FROM pengguna WHERE email = '$email'")->row_array();
    if ($query > 0) {
      $this->_sendEmail($query['nama'], $query['email'], $query['kode_otp']);
      $message = array(
        'status' => true,
        'data' => "Kode OTP telah di kirim ke Email Anda"
      );
      $this->response($message, REST_Controller::HTTP_OK);
    } else {
      $message = array(
        'status' => false,
        'data' => "Akun Anda Belum Terdaftar"
      );

      $this->response($message, REST_Controller::HTTP_OK);
    }
  }
  public function _sendEmail($name, $email, $kodeOTP)
  {
    $this->load->library('email');

    $config = [
      'protocol'  => 'smtp',
      'smtp_host' => 'ssl://smtp.googlemail.com',
      'smtp_user' => 'spacenad3@gmail.com',
      'smtp_pass' => 'Sukses2021',
      'smtp_port' => 465,
      'mailtype'  => 'html',
      'charset'   => 'utf-8',
      'newline'   => "\r\n"
    ];

    $this->email->initialize($config);

    $this->email->from('spacenad3@gmail.com', 'Sistem Penyewaan Gedung Desa Ngoran');


    $data = array(

      'userName' => $name,
      'kodeOTP' => $kodeOTP,

    );
    $this->email->to($email);
    $this->email->subject('Sistem Penyewaan Gedung Desa Ngoran');
    $this->email->message('Sistem Penyewaan Gedung Desa Ngoran');
    $body = $this->load->view('temp_pass.php', $data, TRUE);

    $this->email->message($body);
    if ($this->email->send()) {
      // echo 'Sukses';
    } else {
      echo $this->email->print_debugger();
      die;
    }
  }
}
