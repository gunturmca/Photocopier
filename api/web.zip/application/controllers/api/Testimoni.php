<?php
defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Testimoni extends REST_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('User_Model', 'UserModel');
  }
  public function index_post()
  {
    $config['allowed_types'] = 'jpg|jpeg|png|gif';
    $config['max_size'] = '2048';
    $config['upload_path'] = './uploads/testimoni/';
    $config['encrypt_name'] = TRUE;
    $this->load->library('upload');
    $this->upload->initialize($config);

    if ($this->upload->do_upload('gambar_testimoni')) {
      $fotobaru = $this->upload->data('file_name');
      $arr = [
        'gambar_testimoni' => $fotobaru,
        'ulasan' => $this->input->post('ulasan'),
        'tanggal' => date('Y-m-d'),
        'id_pengguna' => $this->input->post('id_pengguna'),
      ];
      if ($this->UserModel->insert('testimoni', $arr)) {
        $response = [
          'status' => true,
          'pesan' => 'Testimoni Berhasil',
        ];
        $this->response($response, 200);
      } else {
        $response = [
          'status' => true,
          'pesan' => 'Testimoni Gagal',
        ];
        $this->response($response, 404);
      }
    } else if (!$this->upload->do_upload('gambar_testimoni')) {
      $arr = [
        'gambar_testimoni' => '',
        'ulasan' => $this->input->post('ulasan'),
        'tanggal' => date('Y-m-d'),
        'id_pengguna' => $this->input->post('id_pengguna'),
      ];
      if ($this->UserModel->insert('testimoni', $arr)) {
        $response = [
          'status' => true,
          'pesan' => 'Testimoni Berhasil',
        ];
        $this->response($response, 200);
      } else {
        $response = [
          'status' => true,
          'pesan' => 'Testimoni Gagal',
        ];
        $this->response($response, 404);
      }
    } else {
      $response = [
        'status' => false,
        'pesan' => 'Terjadi Kesalahan',

      ];
      $this->response($response, 404);
    }
  }
  public function index_get()
  {
    $data = $this->db->query("SELECT testimoni.* , pengguna.nama FROM testimoni , pengguna WHERE testimoni.id_pengguna = pengguna.id_pengguna")->result_array();
    if ($data) {
      $response = [
        'status' => true,
        'pesan' => $data,
      ];
      $this->response($response, 200);
    } else {
      $response = [
        'status' => false,
        'pesan' => 'Testimoni Tidak Ada',
      ];
      $this->response($response, 400);
    }
  }
}
