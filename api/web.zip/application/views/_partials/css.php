<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/icofont/icofont.min.css" rel="stylesheet">
<link href="assets/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/venobox/venobox.css" rel="stylesheet">
<link href="assets/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/aos/aos.css" rel="stylesheet">

<link href="css/style.css" rel="stylesheet">