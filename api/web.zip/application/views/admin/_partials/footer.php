<footer class="footer mt-auto footer-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-md-right small">
                <?php echo "Desa Ngoran" ?> |
                <script>
                    document.write(new Date().getFullYear());
                </script>
            </div>
        </div>
    </div>
</footer>