<div id="layoutSidenav_nav">
    <nav class="sidenav shadow-right sidenav-light">
        <div class="sidenav-menu">
            <div class="nav accordion" id="accordionSidenav">

                <!-- DASHBOARD -->
                <div class="sidenav-menu-heading">Dashboard</div>
                <a class="nav-link" href="<?php echo base_url('admin/Dashboard') ?>">
                    <div class="nav-link-icon"><i data-feather="home"></i></div>
                    Dashboard
                </a>

                <!-- ABOUT -->
                <div class="sidenav-menu-heading">Master Data</div>
                <a class="nav-link" href="<?php echo base_url('admin/Profile') ?>">
                    <div class="nav-link-icon"><i data-feather="user"></i></div>
                    Profil Gedung
                </a>

                <!-- CATEGORY -->
                <a class="nav-link collapsed" href="<?php echo base_url('admin/Fasilitas') ?>">
                    <div class="nav-link-icon"><i data-feather="grid"></i></div>
                    Fasilitas
                </a>

                <!-- CONTACT -->
                <a class="nav-link" href="<?php echo base_url('admin/UnitDesa') ?>">
                    <div class="nav-link-icon"><i data-feather="mail"></i></div>
                    Unit Desa
                </a>
                <a class="nav-link collapsed" href="<?php echo base_url('admin/User') ?>">
                    <div class="nav-link-icon"><i data-feather="file-text"></i></div>
                    User
                </a>
                <!-- HERO -->
                <a class="nav-link collapsed" href="<?php echo base_url('admin/Acara') ?>">
                    <div class="nav-link-icon"><i data-feather="image"></i></div>
                    Acara
                </a>


                <a class="nav-link collapsed" href="<?php echo base_url('admin/Lampu') ?>">
                    <div class="nav-link-icon"><i data-feather="file-text"></i></div>
                    Lampu
                </a>
                <a class="nav-link collapsed" href="<?php echo base_url('admin/Testimoni') ?>">
                    <div class="nav-link-icon"><i data-feather="file-text"></i></div>
                    Testimoni
                </a>

            </div>
        </div>
        <div class="sidenav-footer">
            <div class="sidenav-footer-content">
                <div class="sidenav-footer-subtitle">Logged in as:</div>
                <div class="sidenav-footer-title"><?= $Pengguna['nama'] ?></div>
            </div>
        </div>
    </nav>
</div>