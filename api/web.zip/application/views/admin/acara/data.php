<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php $this->load->view("admin/_partials/head.php") ?>

<body class="nav-fixed">

  <!-- Topbar -->
  <?php $this->load->view("admin/_partials/topbar.php") ?>

  <div id="layoutSidenav">

    <!-- Sidebar -->
    <?php $this->load->view("admin/_partials/sidebar.php") ?>

    <div id="layoutSidenav_content">
      <main>
        <div class="page-header pb-10 page-header-dark bg-gradient-primary-to-secondary">
          <div class="container-fluid">
            <div class="page-header-content">
              <h1 class="page-header-title">
                <div class="page-header-icon"><i data-feather="monitor"></i></div>
                <span>Acara</span>
              </h1>
            </div>
          </div>
        </div>
        <div class="container-fluid mt-n10">
          <div class="card mb-4">
            <div class="card-header">
              <a class="btn btn-primary btn-sm shadow-sm" href="<?php echo base_url('admin/Acara/add') ?>">
                Tambah Acara
              </a>
            </div>
            <div class="card-body">
              <div class="col">
                <?php echo $this->session->flashdata('pesan') ?>
              </div>
              <div class="datatable table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Acara</th>
                      <th>Tanggal Mulai</th>
                      <th>Tanggal Selesai</th>
                      <!-- <th>Nama Pengguna</th> -->
                      <th>Tipe Acara</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $no = 1;
                    foreach ($data as $data) { ?>

                      <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $data['nama_acara'] ?></td>
                        <td><?= $data['tanggal_mulai'] ?></td>
                        <td><?= $data['tanggal_selesai'] ?></td>
                        <!-- <td><?= $data['id_pengguna'] ?></td> -->
                        <td>
                          <?php if ($data['tipe_acara'] == 1) { ?>
                            <div class="badge badge-cyan badge-pill">Online</div>
                          <?php } ?>
                          <?php if ($data['tipe_acara'] == 2) { ?>
                            <div class="badge badge-dark badge-pill">Offline</div>
                          <?php } ?>
                        </td>
                        <td>
                          <?php if ($data['status'] == 1) { ?>
                            <div class="badge badge-warning badge-pill">Menunggu Konfirmasi</div>
                          <?php } ?>
                          <?php if ($data['status'] == 2) { ?>
                            <div class="badge badge-success badge-pill">Diterima</div>
                          <?php } ?>
                          <?php if ($data['status'] == 3) { ?>
                            <div class="badge badge-danger badge-pill">Ditolak</div>
                          <?php } ?>
                          <?php if ($data['status'] == 4) { ?>
                            <div class="badge badge-primary badge-pill">Selesai</div>
                          <?php } ?>
                        </td>
                        <td>
                          <a class="btn btn-datatable btn-icon btn-transparent-dark" href="<?php echo base_url('admin/Acara/fasilitas/' . $data['id_acara']) ?>"><i data-feather="home"></i></a>
                          <a class="btn btn-datatable btn-icon btn-transparent-dark" href="<?php echo base_url('admin/Acara/detail/' . $data['id_acara']) ?>"><i data-feather="plus"></i></a>
                          <a class="btn btn-datatable btn-icon btn-transparent-dark" href="" onclick="confirm_hapus('<?php echo base_url('admin/Acara/hapus/' . $data['id_acara']) ?>')" data-toggle="modal" data-target="#modalDelete"><i data-feather="trash-2"></i></a>
                        </td>
                      </tr>
                    <?php } ?>
                  </tbody>
                </table>
                <div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Hapus Data</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">×</span>
                        </button>
                      </div>
                      <div class="modal-body">Apakah Anda yakin untuk hapus data?</div>
                      <div class="modal-footer">
                        <button class="btn btn-primary" type="button" data-dismiss="modal">Batal</button>
                        <a class="btn btn-danger" id="delete_link" type="button" href="">Hapus</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <!-- Footer -->
      <?php $this->load->view("admin/_partials/footer.php") ?>

    </div>
  </div>

  <!-- JS -->
  <?php $this->load->view("admin/_partials/js.php") ?>

</body>
<script>
  function confirm_hapus(add) {
    $('#modalDelete').modal('show', {
      backdrop: 'static'
    });
    document.getElementById('delete_link').setAttribute('href', add);
  }
</script>

</html>