<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php $this->load->view("admin/_partials/head.php") ?>
<?php $this->load->view("admin/_partials/modal/save.php") ?>

<body class="nav-fixed">

  <!-- Topbar -->
  <?php $this->load->view("admin/_partials/topbar.php") ?>

  <div id="layoutSidenav">

    <!-- Sidebar -->
    <?php $this->load->view("admin/_partials/sidebar.php") ?>

    <div id="layoutSidenav_content">
      <main>
        <div class="page-header pb-10 page-header-dark bg-gradient-primary-to-secondary">
          <div class="container-fluid">
            <div class="page-header-content">
              <h1 class="page-header-title">
                <div class="page-header-icon"><i data-feather="edit-3"></i></div>
                <span>Detail Acara</span>
              </h1>
            </div>
          </div>
        </div>
        <div class="container-fluid mt-n10">
          <form action="" method="post">
            <div class="card mb-4">
              <div class="card-header">Detail Acara</div>
              <div class="card-body">
                <div class="row">
                  <div class="form-group col-lg-4 col-sm-12">
                    <label>Nama Acara</label>
                    <p><b><?= $data['nama_acara'] ?></b></p>
                  </div>

                  <?php if ($data['tipe_acara'] == 1) {
                    $qry = $this->db->query("SELECT * FROM acara , pengguna WHERE acara.id_pengguna = pengguna.id_pengguna")->row_array();
                  ?>
                    <div class="form-group col-lg-4 col-sm-12">
                      <label>Jumlah Peserta</label>
                      <p><b><?= $data['jumlah_peserta'] ?></b></p>
                    </div>
                    <div class="form-group col-lg-4 col-sm-12">
                      <label>Nama Pemesan</label>
                      <p><b><?= $qry['nama'] ?></b></p>
                    </div>
                  <?php } else { ?>
                    <div class="form-group col-lg-6 col-sm-12">
                      <label>Jumlah Peserta</label>
                      <p><b><?= $data['jumlah_peserta'] ?></b></p>
                    </div>
                  <?php } ?>

                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Tanggal Mulai</label>
                    <p><b><?= $data['tanggal_mulai'] ?></b></p>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Tanggal Selesai</label>
                    <p><b><?= $data['tanggal_selesai'] ?></b></p>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Jenis Kegiatan</label>
                    <p><b><?= $data['jenis_kegiatan'] ?></b></p>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Deskripsi</label>
                    <p><b><?= $data['deskripsi'] ?></b></p>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Status</label>
                    <br>
                    <?php if ($data['status'] == 1) { ?>
                      <div class="badge badge-warning badge-pill">Menunggu Konfirmasi</div>
                    <?php } ?>
                    <?php if ($data['status'] == 2) { ?>
                      <div class="badge badge-success badge-pill">Diterima</div>
                    <?php } ?>
                    <?php if ($data['status'] == 3) { ?>
                      <div class="badge badge-danger badge-pill">Ditolak</div>
                    <?php } ?>
                    <?php if ($data['status'] == 4) { ?>
                      <div class="badge badge-primary badge-pill">Selesai</div>
                    <?php } ?>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Tipe Acara</label>
                    <br>
                    <?php if ($data['tipe_acara'] == 1) { ?>
                      <div class="badge badge-cyan badge-pill">Online</div>
                    <?php } ?>
                    <?php if ($data['tipe_acara'] == 2) { ?>
                      <div class="badge badge-dark badge-pill">Offline</div>
                    <?php } ?>
                  </div>
                </div>
              </div>
            </div>
            <?php if ($data['tipe_acara'] == 1 && $data['status'] == 1) { ?>
              <a class="btn btn-primary mr-2" href="<?= base_url('admin/Acara/Terima/' . $data['id_acara']) ?>">
                Terima
              </a>
              <a class="btn btn-danger" href="<?= base_url('admin/Acara/Tolak/' . $data['id_acara']) ?>">
                Tolak
              </a>
            <?php } ?>
            <?php if ($data['status'] == 2) { ?>
              <a class="btn btn-primary mr-2" href="<?= base_url('admin/Acara/Selesai/' . $data['id_acara']) ?>">
                Selesai
              </a>
            <?php } ?>

          </form>
        </div>
      </main>

      <!-- Footer -->
      <?php $this->load->view("admin/_partials/footer.php") ?>

    </div>
  </div>

  <!-- JS -->
  <?php $this->load->view("admin/_partials/js.php") ?>

</body>

</html>