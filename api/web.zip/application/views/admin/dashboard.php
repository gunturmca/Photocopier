<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php $this->load->view("admin/_partials/head.php") ?>

<body class="nav-fixed">

  <!-- Topbar -->
  <?php $this->load->view("admin/_partials/topbar.php") ?>

  <div id="layoutSidenav">

    <!-- Sidebar -->
    <?php $this->load->view("admin/_partials/sidebar.php") ?>

    <div id="layoutSidenav_content">
      <main>
        <!-- Main page content-->
        <div class="container mt-5">
          <!-- Custom page header alternative example-->
          <div class="d-flex justify-content-between align-items-sm-center flex-column flex-sm-row mb-4">
            <div class="mr-4 mb-3 mb-sm-0">
              <h1 class="mb-0">Halaman Utama</h1>
              <div class="small">
                <span class="font-weight-500 text-primary"><?= date('D') ?></span>
                &middot; <?= date('Y-m-d') ?>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-xl-3 col-md-6 mb-4">
              <!-- Dashboard info widget 1-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-primary h-100">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                      <div class="small font-weight-bold text-primary mb-1">Jumlah User</div>
                      <div class="h5"><?= $user ?></div>

                    </div>
                    <div class="ml-2"><i class="fas fa-user fa-2x text-gray-200"></i></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <!-- Dashboard info widget 2-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-secondary h-100">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                      <div class="small font-weight-bold text-secondary mb-1">Jumlah Fasilitas</div>
                      <div class="h5"><?= $fasilitas ?></div>

                    </div>
                    <div class="ml-2"><i class="fas fa-tag fa-2x text-gray-200"></i></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <!-- Dashboard info widget 3-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-success h-100">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                      <div class="small font-weight-bold text-success mb-1">Jumlah Pemesanan Gedung</div>
                      <div class="h5"><?= $pemesan ?></div>

                    </div>
                    <div class="ml-2"><i class="fas fa-mouse-pointer fa-2x text-gray-200"></i></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
              <!-- Dashboard info widget 4-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-info h-100">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                      <div class="small font-weight-bold text-info mb-1">Jumlah Pemesanan Gedung Menunggu</div>
                      <div class="h5"><?= $menunggu ?></div>

                    </div>
                    <div class="ml-2"><i class="fas fa-percentage fa-2x text-gray-200"></i></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 mb-4">
              <!-- Area chart example-->
              <div class="card mb-4">
                <div class="card-header">Grafik Pemesanan Gedung</div>
                <div class="card-body">
                  <div class="chart-area"><canvas id="myBarChart" width="100%" height="30"></canvas></div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 mb-4">

              <div class="card mb-4">
                <div class="card-body text-center p-5">
                  <h4>Lampu</h4>
                  <div class="datatable table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable" width="" cellspacing="0">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama</th>
                          <th>Tindakan</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1;
                        foreach ($lampu as $lampu) { ?>
                          <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $lampu['nama_lampu'] ?></td>
                            <td>
                              <?php if ($lampu['tindakan'] == 'On') { ?>
                                <div class="badge badge-primary badge-pill">Active</div>
                              <?php } else { ?>
                                <div class="badge badge-danger badge-pill">Off</div>
                              <?php } ?>
                            </td>
                            <td>
                              <?php if ($lampu['tindakan'] == 'On') { ?>
                                <a class="btn btn-datatable btn-icon btn-transparent-dark" href="<?php echo base_url('admin/Lampu/off/' . $lampu['id_lampu']) ?>"><i data-feather="toggle-left"></i></a>
                              <?php } else { ?>
                                <a class="btn btn-datatable btn-icon btn-transparent-dark" href="<?php echo base_url('admin/Lampu/on/' . $lampu['id_lampu']) ?>"><i data-feather="toggle-right"></i></a>
                              <?php } ?>
                            </td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mb-5">
            <div class="container-fluid">
              <div class="card mb-4">
                <div class="card-header">
                  Testimoni
                </div>
                <div class="card-body">
                  <div class="col">
                    <?php echo $this->session->flashdata('pesan') ?>
                  </div>
                  <div class="datatable table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama Pengguna</th>
                          <th>Gambar Testimoni</th>
                          <th>Ulasan</th>
                          <th>Tanggal</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1;
                        foreach ($testi as $f) { ?>
                          <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $f['nama'] ?></td>
                            <td>
                              <img src="<?= base_url('uploads/testimoni/') .  $f['gambar_testimoni'] ?>" alt="" width="120px">
                            </td>
                            <td><?= $f['ulasan'] ?></td>
                            <td>
                              <?= $f['tanggal'] ?>
                            </td>

                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                    <div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel">Hapus Data</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">×</span>
                            </button>
                          </div>
                          <div class="modal-body">Apakah Anda yakin untuk hapus data?</div>
                          <div class="modal-footer">
                            <button class="btn btn-primary" type="button" data-dismiss="modal">Batal</button>
                            <a class="btn btn-danger" id="delete_link" type="button" href="">Hapus</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </main>

      <!-- Footer -->
      <?php $this->load->view("admin/_partials/footer.php") ?>

    </div>
  </div>

  <!-- JS -->
  <?php $this->load->view("admin/_partials/js.php") ?>

</body>
<script>
  (Chart.defaults.global.defaultFontFamily = "Metropolis"),
  '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
  Chart.defaults.global.defaultFontColor = "#858796";

  var ctx = document.getElementById("myBarChart");
  var cData = JSON.parse(`<?php echo $grafik; ?>`);
  var myLineChart = new Chart(ctx, {
    type: "line",
    data: {
      // labels: [
      // 	"Januari",
      // 	"Februari",
      // 	"Maret",
      // 	"April",
      // 	"Mei",
      // 	"Juni",
      // 	"Juli",
      // 	"Agustus",
      // 	"September",
      // 	"Oktober",
      // 	"November",
      // 	"Desember"
      // ],
      labels: cData.tanggal,
      datasets: [{
        label: "Earnings ",
        lineTension: 0.3,
        backgroundColor: "rgba(0, 97, 242, 0.05)",
        borderColor: "rgba(0, 97, 242, 1)",
        pointRadius: 3,
        pointBackgroundColor: "rgba(0, 97, 242, 1)",
        pointBorderColor: "rgba(0, 97, 242, 1)",
        pointHoverRadius: 3,
        pointHoverBackgroundColor: "rgba(0, 97, 242, 1)",
        pointHoverBorderColor: "rgba(0, 97, 242, 1)",
        pointHitRadius: 10,
        pointBorderWidth: 2,
        // data: [
        // 	0,
        // 	10,
        // 	5,
        // 	15,
        // 	10,
        // 	20,
        // 	15,
        // 	25,
        // 	20,
        // 	30,
        // 	25,
        // 	40
        // ]
        data: cData.jumlah
      }]
    },
    options: {
      maintainAspectRatio: false,
      layout: {
        padding: {
          left: 10,
          right: 25,
          top: 25,
          bottom: 0
        }
      },
      scales: {
        xAxes: [{
          time: {
            unit: "date"
          },
          gridLines: {
            display: false,
            drawBorder: false
          },
          ticks: {
            maxTicksLimit: 7
          }
        }],
        yAxes: [{
          ticks: {
            maxTicksLimit: 5,
            padding: 10,
            callback: function(value, index, values) {
              return number_format(value);
            }
          },
          gridLines: {
            color: "rgb(234, 236, 244)",
            zeroLineColor: "rgb(234, 236, 244)",
            drawBorder: false,
            borderDash: [2],
            zeroLineBorderDash: [2]
          }
        }]
      },
      legend: {
        display: false
      },
      tooltips: {
        backgroundColor: "rgb(255,255,255)",
        bodyFontColor: "#858796",
        titleMarginBottom: 10,
        titleFontColor: "#6e707e",
        titleFontSize: 14,
        borderColor: "#dddfeb",
        borderWidth: 1,
        xPadding: 15,
        yPadding: 15,
        displayColors: false,
        intersect: false,
        mode: "index",
        caretPadding: 10,
        callbacks: {
          label: function(tooltipItem, chart) {
            var datasetLabel =
              chart.datasets[tooltipItem.datasetIndex].label || "";
            return datasetLabel + number_format(tooltipItem.yLabel);
          }
        }
      }
    }
  });
</script>

</html>