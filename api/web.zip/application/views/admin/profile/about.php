<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php $this->load->view("admin/_partials/head.php") ?>
<!-- <?php $this->load->view("admin/_partials/modal/save.php") ?> -->

<body class="nav-fixed">

  <!-- Topbar -->
  <?php $this->load->view("admin/_partials/topbar.php") ?>

  <div id="layoutSidenav">

    <!-- Sidebar -->
    <?php $this->load->view("admin/_partials/sidebar.php") ?>

    <div id="layoutSidenav_content">
      <main>
        <div class="page-header pb-10 page-header-dark bg-gradient-primary-to-secondary">
          <div class="container-fluid">
            <div class="page-header-content">
              <h1 class="page-header-title">
                <div class="page-header-icon"><i data-feather="user"></i></div>
                <span>About</span>
              </h1>
            </div>
          </div>
        </div>
        <div class="container-fluid mt-n10">
          <form action="<?= base_url('admin/Profile/update') ?>" method="post" enctype="multipart/form-data">
            <div class="card mb-4">
              <div class="card-header">About Gedung</div>

              <div class="card-body">
                <div class="col">
                  <?php echo $this->session->flashdata('pesan') ?>
                </div>
                <div class="row">
                  <div class="form-group col-lg-12 col-sm-12">
                    <label>Nama Gedung</label>
                    <input class="form-control" id="nama" name="nama" type="text" value="<?= $profile->nama ?>" />
                    <input class="form-control" id="id" name="id" type="text" value="<?= $profile->id ?>" hidden />
                  </div>
                  <div class="form-group col-lg-12 col-sm-12">
                    <label>Deskripsi</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" type="text" placeholder="Deskripsi"><?= $profile->deskripsi ?></textarea>
                  </div>
                </div>
              </div>
            </div>
            <button name="save" id="save" type="submit" class="btn btn-primary mr-2" href="#" data-toggle="modal" data-target="#modalSave">
              Save
            </button>
            <a class="btn btn-danger" href="javascript:history.go(-1)">
              Cancel
            </a>

          </form>

        </div>
      </main>

      <!-- Footer -->
      <?php $this->load->view("admin/_partials/footer.php") ?>

    </div>
  </div>

  <!-- JS -->
  <?php $this->load->view("admin/_partials/js.php") ?>

</body>
<script>
  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function(e) {
        $('#preview').attr('src', e.target.result);
      }

      reader.readAsDataURL(input.files[0]); // convert to base64 string
    }
  }

  $("#foto").change(function() {
    readURL(this);
  });
</script>

</html>