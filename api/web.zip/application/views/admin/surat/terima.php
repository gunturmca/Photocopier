<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <p>Ini Surat Terima</p>
    <p>Nama Pengguna : <?= $surat['nama'] ?></p>
    <p>Nama Acara : <?= $surat['nama_acara'] ?></p>
    <p>Tanggal Mulai : <?= $surat['tanggal_mulai'] ?></p>
    <p>Tanggal Selesai : <?= $surat['tanggal_selesai'] ?></p>
    <p>Jumlah Peserta : <?= $surat['jumlah_peserta'] ?></p>
    <p>Jenis Kegiatan : <?= $surat['jenis_kegiatan'] ?></p>
    <p>Deskripsi : <?= $surat['deskripsi'] ?></p>
    <p>Nama Acara : <?= $surat['nama_acara'] ?></p>

</body>
<script>
    window.print()
</script>

</html>