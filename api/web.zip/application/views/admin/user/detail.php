<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php $this->load->view("admin/_partials/head.php") ?>
<?php $this->load->view("admin/_partials/modal/save.php") ?>

<body class="nav-fixed">

  <!-- Topbar -->
  <?php $this->load->view("admin/_partials/topbar.php") ?>

  <div id="layoutSidenav">

    <!-- Sidebar -->
    <?php $this->load->view("admin/_partials/sidebar.php") ?>

    <div id="layoutSidenav_content">
      <main>
        <div class="page-header pb-10 page-header-dark bg-gradient-primary-to-secondary">
          <div class="container-fluid">
            <div class="page-header-content">
              <h1 class="page-header-title">
                <div class="page-header-icon"><i data-feather="edit-3"></i></div>
                <span>Detail Pengguna</span>
              </h1>
            </div>
          </div>
        </div>
        <div class="container-fluid mt-n10">
          <form action="" method="post">
            <div class="card mb-4">
              <div class="card-header">Detail Pengguna</div>
              <div class="card-body">
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Nama Pengguna</label>
                    <p><b><?= $data['nama'] ?></b></p>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Email</label>
                    <p><b><?= $data['email'] ?></b></p>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Alamat Rumah</label>
                    <p><b><?= $data['alamat'] ?></b></p>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Nomor Telepon</label>
                    <p><b><?= $data['nomor_telepon'] ?></b></p>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Kota</label>
                    <p><b><?= $data['kota_kab'] ?></b></p>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Provinsi</label>
                    <p><b><?= $data['provinsi'] ?></b></p>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Aktif</label>
                    <br>
                    <?php if ($data['is_active'] == 1) { ?>
                      <div class="badge badge-primary badge-pill">Aktif</div>
                    <?php } ?>
                    <?php if ($data['is_active'] == 2) { ?>
                      <div class="badge badge-success badge-pill">Off</div>
                    <?php } ?>
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Jenis Kelamin</label>
                    <br>
                    <div class="badge badge-warning badge-pill"><?= $data['jenis_kelamin'] ?></div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Profile</label>
                    <br>
                    <img src="<?= base_url('uploads/profile_user/') . $data['foto_pengguna'] ?>" alt="" width="120px">
                  </div>
                  <div class="form-group col-lg-6 col-sm-12">
                    <label>Bergabung Tanggal</label>
                    <br>
                    <p><b><?= $data['created_at'] ?></b></p>
                  </div>
                </div>
                <div class="row">
                  <?php if ($data['is_active'] == 1) { ?>
                    <a class="btn btn-danger mr-2" href="<?= base_url('admin/User/Off/' . $data['id_pengguna']) ?>">
                      Blokir Akun
                    </a>
                  <?php } ?>
                  <?php if ($data['is_active'] == 2) { ?>
                    <a class="btn btn-success mr-2" href="<?= base_url('admin/User/On/' . $data['id_pengguna']) ?>">
                      Aktifkan Akun
                    </a>
                  <?php } ?>
                </div>
              </div>
            </div>
          </form>
        </div>
      </main>

      <!-- Footer -->
      <?php $this->load->view("admin/_partials/footer.php") ?>

    </div>
  </div>

  <!-- JS -->
  <?php $this->load->view("admin/_partials/js.php") ?>

</body>

</html>